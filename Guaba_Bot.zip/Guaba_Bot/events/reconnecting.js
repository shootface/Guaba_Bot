const Discord = require('discord.js');

module.exports = client => {
    console.log(`you have been reconnecting at ${new Date()}`);
}