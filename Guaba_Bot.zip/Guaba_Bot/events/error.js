const Discord = require('discord.js');

module.exports = client => {
    console.error();
}