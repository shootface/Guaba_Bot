const Discord = require('discord.js');

module.exports = client => {
    console.log(`you have been disconected at ${new Date()}`);
}